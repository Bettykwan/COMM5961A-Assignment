document.getElementById('scroll_to_cards').addEventListener('click', scroll_to_cards);

function scroll_to_cards() {
    let element = document.querySelector("#cards");
    element.scrollIntoView({behavior: 'smooth', block: 'center'});  
}